# Maze [![Open in Streamlit](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io/maxwellreynolds/maze/ui.py)
### Solving mazes with Dijkstra's Algorithm

![Alt Text](mazeui.png)

![Alt Text](mazeui2.png)


Try here:  
https://maxwellreynolds-maze-ui-evjnk5.streamlitapp.com/
